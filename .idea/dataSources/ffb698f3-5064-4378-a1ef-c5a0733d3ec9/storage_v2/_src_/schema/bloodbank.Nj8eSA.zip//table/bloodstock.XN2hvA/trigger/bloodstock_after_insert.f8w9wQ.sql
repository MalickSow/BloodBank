create definer = malick@localhost trigger bloodstock_AFTER_INSERT
    after insert
    on bloodstock
    for each row
BEGIN
insert into bloodactivity (fkdonorid,bloodgroup,fklocation) values(new.fkdonor,new.bloodgroup,new.fklocation);
END;

